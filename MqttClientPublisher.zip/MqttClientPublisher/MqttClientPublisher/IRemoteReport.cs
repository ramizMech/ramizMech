﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MqttClientPublisher
{
    public interface IRemoteReport
    {
        public string GetReport();
        
    }
}
